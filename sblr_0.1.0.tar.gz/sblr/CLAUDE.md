# CLAUDE.md

## Project
This repository contains `sblr`, an experimental R package for **Scalable Bayesian Linear Regression** models.
The package is used for Bayesian genomic prediction and variable selection with:
- GWAS summary statistics
- sparse linkage disequilibrium matrices
- PLINK BED genotype files
- annotation-informed priors
- C++/Rcpp/OpenMP MCMC samplers

This is a research snapshot, not a finished production or CRAN-ready package.

## General rules
- Check `git status --short` before editing.
- Do not overwrite unrelated user changes.
- Keep edits small and focused.
- Do not commit or push unless explicitly asked.
- Do not delete files unless explicitly asked.
- Report what was inspected, changed, and tested.

## R package rules
- Preserve standard R package structure.
- Use roxygen comments for exported function documentation.
- Do not edit `NAMESPACE` or `man/*.Rd` by hand unless explicitly asked.
- Run `devtools::document()` when roxygen documentation or exports change.
- Avoid adding new dependencies unless clearly justified.
- Keep examples reproducible where possible.
- Avoid machine-specific absolute paths in package code.

## Native-code rules
The package contains experimental C++/Rcpp/OpenMP code.
When editing native code:
- Be conservative.
- Do not change R/C++ function signatures without updating wrappers and documentation.
- Do not change sampler logic unless explicitly asked.
- Do not change random-number behavior without explaining it.
- Do not make broad refactors across multiple sampler implementations in one step.
- Do not commit generated native build artifacts.

Generated native files that should not be committed:
src/*.o, src/*.obj, src/*.dll, src/*.so, src/*.dylib, src/*.lib, src/*.a, src/*.exe

## Claude-specific notes
- Prefer `/read` to explore unfamiliar files before editing.
- Use Plan Mode (`Shift+Tab` to toggle) for large or risky changes before applying them.
- Ask before running `devtools::install()` or anything that recompiles C++ code.
- Do not run MCMC samplers as part of verification — they are slow and resource-intensive.
